<?php 
include_once 'dbconfig.php';

class Dao 
{
	var $link;
	public function __construct()
	{
			$this->link = new Dbconfig(); //object
		}
		public function tampilData()
		{
			$query = "SELECT * FROM user";
			return mysqli_query($this->link->conn, $query);	
		}

		public function tampilSurah()
		{
			$query = "SELECT * FROM surah";
			return mysqli_query($this->link->conn, $query);	
		}

		public function tampilHafalan()
		{
			$query = "SELECT max(hafalan.waktu) as waktu, hafalan.nim, hafalan.id_target, hafalan.ayat, hafalan.nama_surah, hafalan.status, mahasiswa.nama_mahasiswa, surah.nama_surah AS nsurah, target.ayat AS nayat FROM hafalan, mahasiswa, target, surah WHERE `mahasiswa`.nim = `hafalan`.nim AND `target`.id_target = `hafalan`.id_target AND `target`.id_surah = `surah`.id_surah GROUP BY `mahasiswa`.nim";
			return mysqli_query($this->link->conn, $query);	
		}

		public function tampilMahasiswa()
		{
			$query = "SELECT * from mahasiswa";
			return mysqli_query($this->link->conn, $query);	
		}

		public function tampilTarget()
		{
			$query = "SELECT target.*, surah.* FROM target, surah where `surah`.id_surah = `target`.id_surah";
			return mysqli_query($this->link->conn, $query);	
		}
		public function tampilOrangtua()
		{
			$query = "SELECT orang_tua.*, `mahasiswa`.nama_mahasiswa FROM orang_tua, mahasiswa WHERE mahasiswa.nim = orang_tua.nim";
			return mysqli_query($this->link->conn, $query);	
		}

		public function cekLogin($username, $password)
		{
			$query = "SELECT * FROM USER WHERE username = '$username' AND PASSWORD = PASSWORD('$password')";
			return mysqli_query($this->link->conn, $query);	
		}

		public function tampilNIM()
		{
			$query = "SELECT nim, nama_mahasiswa FROM mahasiswa order by nim asc";
			return mysqli_query($this->link->conn, $query);	
		}

		public function selisih($nilai1, $nilai2){
			$hasil = $nilai1-$nilai2;
			return (int)$hasil;	
		}

		public function detailHafalan($nim)
		{
			$query = "SELECT hafalan.*, surah.nama_surah AS nsurah, target.ayat AS nayat FROM hafalan, mahasiswa, target, surah WHERE `mahasiswa`.nim = `hafalan`.nim AND `target`.id_target = `hafalan`.id_target AND `target`.id_surah = `surah`.id_surah AND `hafalan`.nim = '$nim' ORDER BY hafalan.waktu DESC";
			return mysqli_query($this->link->conn, $query);	
		}

		public function grafik($nim){
			$query = "SELECT * FROM hafalan WHERE nim ='$nim'";//" ORDER BY waktu DESC LIMIT 10";
			return mysqli_query($this->link->conn, $query);	
		}

		public function grafikHome(){
			$query = "SELECT MONTH(waktu) AS bln, YEAR(waktu) AS th, COUNT(`status`) AS jml FROM hafalan 
			WHERE `status` = 'tercapai' GROUP BY MONTH(waktu)";//" ORDER BY waktu DESC LIMIT 12";
			return mysqli_query($this->link->conn, $query);	
		}

		public function dashboard(){
			$data = array();
			$query = "SELECT COUNT(`status`) AS jml FROM `user` WHERE `status` = 'online'";
			$hasil = mysqli_query($this->link->conn, $query);	
			foreach ($hasil as $value) {
				$data[0] = $value['jml'];
			}

			$query = "SELECT COUNT(*) jml FROM target";
			$hasil = mysqli_query($this->link->conn, $query);	
			foreach ($hasil as $value) {
				$data[1] = $value['jml'];
			}

			$tercapai = 0;
			$blmtercapai = 0;
			$query = "SELECT MAX(`waktu`), nim, `status` FROM hafalan GROUP BY nim";
			$hasil = mysqli_query($this->link->conn, $query);	
			foreach ($hasil as $value) {
				if ($value['status'] == "Tercapai") {
					$tercapai++;
				}
				elseif ($value['status'] == "Belum Tercapai") {
					$blmtercapai++;
				}
			}
			$data[2] = $tercapai/($tercapai+$blmtercapai)*100;
			$data[3] = $tercapai+$blmtercapai;
			return $data;
		}

		public function execute($query)
		{
			$result = mysqli_query($this->link->conn, $query);
			if ($result) {
				return $result;
			}else{
				return mysqli_error($this->link->conn);
			}
		}


	}

	?>