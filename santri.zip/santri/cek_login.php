<?php 

session_start();
ini_set('display_errors', 'On');
error_reporting(E_ALL);
include_once 'config/dao.php';
$dao = new Dao();
$username = $_POST['username'];
$password = $_POST['password'];
$error='';
$level = 0;
$id = '';

$dao = new Dao();
$result = $dao->cekLogin($username,$password);

$i = 1;
foreach ($result as $value) {
	$level = $value['hak_akses'];
	$id = $value['id_user'];
	$i++;
}
if($result->num_rows == 1){  
	if ($level == "Admin") {
		session_start();
		$query =  "UPDATE `user` SET `status` = 'online' WHERE `id_user`='$id'";
		$dao->execute($query);
		header('location:admin/index.php');
	}
	else {
		session_start();
		header('location:/mhs/index.php');
	}
	session_start();
	$_SESSION['username']=$username;
	$_SESSION['level']=$level; // ini udah ada sessionnya, yang tak pake yang level ya
	//karna dari level kan ketauan dia admin/ortu/mahasiswa
	$_SESSION['id']=$id;
}
else{
	?>
	<script language="JavaScript">
		alert('Login gagal! Username atau Password tidak sesuai.');
		document.location='index.php';
	</script>
	<?php
}
?>