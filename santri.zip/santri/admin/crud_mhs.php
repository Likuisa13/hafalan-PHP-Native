<?php 

include_once '../config/dao.php';
$dao = new Dao();

$aksi = $_POST['aksi'];

if ($aksi == "save") {
	$nim = $_POST['nim']; 
	$nama = $_POST['nama'];
	$tempat = $_POST['tempat'];
	$tgl = $_POST['tgl'];
	$jk = $_POST['jk'];
	$alamat = $_POST['alamat'];
	$jenjang = $_POST['jenjang'];
	$jurusan = $_POST['jurusan'];
	$ipk = $_POST['ipk'];
	$semester = $_POST['semester'];
	$jumlah = $_POST['jumlah'];
	$query = "INSERT INTO `mahasiswa`(`nim`, `nama_mahasiswa`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `alamat`, `prodi`, `jurusan`, `ipk`, `semester`, `jumlah_hafalan`) VALUES ('$nim','$nama','$tempat','$tgl','$jk','$alamat','$jenjang','$jurusan','$ipk','$semester','$jumlah')";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Ditambah!.');
        document.location='mahasiswa.php';
      </script> 
    <?php
}
elseif ($aksi == "edit") {
	$nim = $_POST['nim']; 
	$nama = $_POST['nama'];
	$tempat = $_POST['tempat'];
	$tgl = $_POST['tgl'];
	$jk = $_POST['jk'];
	$alamat = $_POST['alamat'];
	$jenjang = $_POST['jenjang'];
	$jurusan = $_POST['jurusan'];
	$ipk = $_POST['ipk'];
	$semester = $_POST['semester'];
	$jumlah = $_POST['jumlah'];
	$query = "UPDATE `mahasiswa` SET `nama_mahasiswa`='$nama',`jenis_kelamin`='$jk',`tempat_lahir`='$tempat',`tgl_lahir`='$tgl', `alamat`='$alamat',`prodi`='$jenjang',`jurusan`='$jurusan',`ipk`='$ipk',`semester`='$semester',`jumlah_hafalan`='$jumlah' WHERE `nim`='$nim'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Diubah!.');
        document.location='mahasiswa.php';
      </script> 
    <?php
}
else{
	$nim = $_POST['nim']; 
	$query = "DELETE FROM `mahasiswa` WHERE nim = '$nim'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Dihapus!.');
        document.location='mahasiswa.php';
      </script> 
    <?php
}
?>