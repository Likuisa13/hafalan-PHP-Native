<?php 
$html = '<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">';
$html .= '<center><h3>Data Target Hafalan</h3></center><hr/><br/>';
$html .= '<table class="table table-stripped" width="100%">
<tr>
	<td><center>No</center></td>
	<td><center>Surah</center></td>
	<td><center>Ayat Ke</center></td>
</tr>';

include_once '../config/dao.php';
require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$no = 1;
$dao = new Dao();
$orang = $dao->tampilTarget();
foreach ($orang as $value) {
	$html .= "<tr><td><center>".$no."</center></td>";
	$html .="<td><center>".$value['nama_surah']."</center></td>";
	$html .="<td><center>".$value['ayat']."</center></td></tr>";
	$no++;
}
$html .= "</html>";
$dompdf->loadHtml($html);
	// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
	// Rendering dari HTML Ke PDF
$dompdf->render();
	// Melakukan output file Pdf
$dompdf->stream('cetak_target.pdf');
?>