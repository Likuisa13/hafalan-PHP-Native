<?php
error_reporting('off'); //untuk matiin pesan error
session_start();
if ($_SESSION['level'] != "Admin" || empty($_SESSION['level'])) {
	?>
	<script language="JavaScript">
		alert('Silakan lakukan proses login terlebih dahulu !');
		document.location='../index.php';
	</script>
	<?php 
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>STIMIK EL RAHMA | Monitoring dan Evaluasi</title>
	<link rel="icon" href="../img/logo.png">
	<!-- Bootstrap 3.3.7 -->
	<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="../bower_components/jvectormap/jquery-jvectormap.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
  	folder instead of downloading all of them to reduce the load. -->
  	<link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  	<link rel="stylesheet" type="text/css" href="../datatable/dataTables.bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="../plugins/all.min.css">

  	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Google Font -->
<link rel="stylesheet"
href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<script type="text/javascript">
	function delHafalan(id, surah, ayat, nim) {
		$('#idHafalan').val(id);
		$('#nim').val(nim);
		$('#surah').text(surah);
		$('#ayat').text(ayat);
		$('#aksi2').val('delete');
		$('#hafalanDel').modal('show');
	}

</script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">

		<header class="main-header">

			<!-- Logo -->
			<a href="index.php" class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><b>S</b> E-R</span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg"><b>STMIK</b> El-Rahma</span>
			</a>

			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
					<span class="sr-only">Toggle navigation</span>
				</a>
				<!-- Navbar Right Menu -->


			</nav>
		</header>
		<!-- Left side column. contains the logo and sidebar -->
		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				<div class="user-panel">
					<div class="pull-left image">
						<img src="../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
					</div>
					<div class="pull-left info">
						<p>Rizqi Nurhidayah</p>
						<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
					</div>
				</div>

				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu" data-widget="tree">
					<li class="header">MAIN NAVIGATION</li>
					<li>
						<a href="index.php">
							<i class="fa fa-dashboard"></i> <span>Dashboard</span>
						</a>
					</li>
					<li class="treeview">
						<a href="#">
							<i class="fa fa-file-code-o"></i>
							<span>Data Master</span>
							<span class="pull-right-container">
								<span class="label label-primary pull-right"></span>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="mahasiswa.php"><i class="fa fa-circle-o"></i> Data Mahasiswa</a></li>
							<li><a href="orangtua.php"><i class="fa fa-circle-o"></i> Data Orang Tua</a></li>
							<li><a href="target.php"><i class="fa fa-circle-o"></i> Data Target</a></li>
							<!-- <li><a href="target.php"><i class="fa fa-circle-o"></i> DATA HAFALAN</a></li> -->
						</ul>
					</li>
					<li>
						<a href="hafalan.php">
							<i class="fa fa-th"></i> <span>Data Hafalan</span>
							<span class="pull-right-container">
							</span>
						</a>
					</li>
					<li>
						<a href="logout.php">
							<i class="fa fa-sign-out"></i>
							<span>Log Out</span>
						</a>
					</li>
				</ul>
			</section>
			<!-- /.sidebar -->
		</aside>

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
					<li class="active">Dashboard</li>
				</ol>
			</section>
			<!-- Main content -->
			<div class="container">
				<div class="col-md-12"> 
					<!-- menampilkan tabel yang tadi -->
					<h2><center>DATA HAFALAN</center></h2>
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<div class="panel panel-default">
									<div class="panel-heading"><center><strong><h4>DATA DIRI</h4></strong></center></div>
									<?php 
									include_once '../config/dao.php';
									$dao = new Dao();//membuat object dao
									$no = 1;
									$nim = $_GET['nim'];
									$nama;
									$jenjang;
									$prodi;
									$ttl;
									$ipk;
									$jk;
									$status;
									$mhs = $dao->execute("select * from mahasiswa where nim = '$nim'");
									$dao = new Dao();
									$no = 1;
									$orang = $dao->detailHafalan($nim);
									foreach ($orang as $value) {
										$status = $value['nama_surah']." Ayat ".$value['ayat']." (".$value['status'].")";
									}
									foreach ($mhs as $value) {
										$nim = $value['nim'];
										$nama = $value['nama_mahasiswa'];
										$jenjang = $value['prodi'];
										$prodi = $value['jurusan'];
										$ttl = $value['tempat_lahir'].", ".$value['tgl_lahir'];
										$ipk = $value['ipk'];
										$jk = $value['jenis_kelamin'];
									}
									?>
									<div class="panel-body">
										<table class="table table-striped">
											<tr>
												<td rowspan="5"><img width="140" height="200" src="../img/foto/<?php echo $_GET['nim'].".jpg" ?>"></td>
												<td>NIM</td>
												<td> :<?php echo $_GET['nim']; ?></td>
											</tr>
											<tr>
												<td>Nama</td>
												<td> : <?php echo $nama; ?></td>
											</tr>
											<tr>
												<td>Prodi</td>
												<td> : <?php echo $jenjang." ".$prodi; ?></td>
											</tr>
											<tr>
												<td>TTL</td>
												<td> : <?php echo $ttl; ?></td>
											</tr>
											<tr>
												<td>Jenis Kelamin</td>
												<td> : <?php echo $jk ?></td>
											</tr>
											<tr>
												<td>IPK</td>
												<td> : <?php echo $ipk ?></td>
											</tr>
											<tr>
												<td>Status Hafalan</td>
												<td colspan="2"> : <?php echo $status; ?></td>
											</tr>
										</table>

									</div>
									<div class="panel-footer">
										<a href="hafalan.php"><button class="btn btn-primary"><strong>Kembali Ke Data Hafalan</strong></button></a>
										<a target="_blank" href="cetak_dethafalan.php?nim=<?php echo $nim ?>&nama=<?php echo $nama ?>"><button class="btn btn-warning"><i class="fa fa-print"></i><strong> Cetak Data</strong></button></a>
									</div>
								</div>
							</div>
							<div class="col-md-7">
								<div class="panel panel-default">
									<div class="panel-heading"><center><strong><h4>GRAFIK HAFALAN</h4></strong></center></div>
									<div class="panel-body">
										<canvas id="myChart" style=""></canvas>
									</div>
									<div class="panel-footer	">
										<button class="btn btn-primary disabled"><strong>Note : Grafik menampilakn seluruh riwayat hafalan</strong></button>
									</div>
								</div>
							</div>
						</div>
						<div class="container">
							<table class="table table-responsive table-striped table-bordered" id="data">
								<!-- header table -->
								<thead class="btn-primary disabled"> 
									<tr>
										<td>No</td>
										<td>Waktu</td>
										<td>Target Hafalan</td>
										<td>Capaian Hafalan</td>
										<td>Status</td>
										<td>Aksi</td>
									</tr>
								</thead>
								<!-- body table -->
								<tbody>
									<?php 
									foreach ($orang as $value) {
										?>
										<td><center><?php echo $no; ?></center></td>
										<td><center><?php echo $value['waktu']; ?></center></td>
										<td><center><?php echo $value['nsurah']." Ayat ".$value['nayat']; ?></center></td>
										<td><center><?php echo $value['nama_surah']." Ayat ".$value['ayat']; ?></center></td>
										<td><center><?php echo $value['status']; ?></center></td>
										<td nowrap=""><center>
											<button class="btn btn-danger" type="button" onclick="delHafalan('<?php echo $value['id_hafalan'] ?>', '<?php echo $value['nama_surah'] ?>', '<?php echo $value['ayat'] ?>',  '<?php echo $value['nim'] ?>')">Hapus</button>
										</td>
									</tr>
									<?php
									$no++;
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	<!-- Modal Delete -->
	<div class="modal" id="hafalanDel">
		<div class="modal-dialog">
			<div class="modal-content">

				<!-- Modal Header -->
				<div class="modal-header">
					<h4 class="modal-title">Data Hafalan</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>

				<!-- Modal body -->
				<div class="modal-body">
					<form action="crud_hafalan.php" method="POST">

						<h3>Yakin akan menghapus data Hafalan?</h3>
						<center><h2 id="surah"></h2></center>
						<h3><center>Ayat : <span id="ayat"></span></center></h3>
						<input type="hidden" name="idHafalan" id="idHafalan">
						<input type="hidden" name="nim" id="nim">
						<input type="hidden" name="aksi" id="aksi2">
					</div>

					<!-- Modal footer -->
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Delete</button>
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div>
		</div>
	</div>


</div>

<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Version</b> 2.4.13
	</div>
	<strong>Copyright &copy; Rizqi Nurhidayah <a href="https://adminlte.io">STMIK EL-RAHMA</a>.</strong> Kerja Praktik UTY
</footer>

<!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
  	immediately after the control sidebar -->
  	<div class="control-sidebar-bg"></div>

  </div>
  <!-- ./wrapper -->

  <!-- jQuery 3 -->
  <script src="../bower_components/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap 3.3.7 -->
  <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- FastClick -->
  <script src="../bower_components/fastclick/lib/fastclick.js"></script>
  <!-- AdminLTE App -->
  <script src="../dist/js/adminlte.min.js"></script>
  <!-- Sparkline -->
  <script src="../bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
  <!-- jvectormap  -->
  <script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
  <script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- SlimScroll -->
  <script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
  <!-- ChartJS -->
  <script src="../plugins/Chart.min.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../dist/js/pages/dashboard2.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../dist/js/demo.js"></script>
  <script src="../datatable/dataTables.bootstrap.min.js"></script>
  <script src="../datatable/jquery.dataTables.min.js"></script>
  <script src="../plugins/shieldui-all.min.js"></script>
  <script type="text/javascript">
  	$(document).ready(function() {
  		$('#data').DataTable();
  	} );
  </script>
  <script type="text/javascript">
  	var ctx = document.getElementById("myChart").getContext('2d');
  	var myChart = new Chart(ctx, {
  		type: 'line',
  		data: {
  			<?php 
  			$data = $dao->grafik($nim);
  			?>
  			labels: [
  			<?php 
  			foreach ($data as $value) {
  				echo "'".$value['waktu']."',";
  			}
  			?>
  			],
  			datasets: [{
  				label: '# Surah',
  				data: [
  				<?php 
  				foreach ($data as $value) {
  					echo "'".$value['id_surah']."',";
  				}
  				?>
  				],
  				backgroundColor: [
  				'rgba(255, 99, 132, 0.2)',
  				],
  				borderColor: [
  				'rgba(255,99,132,1)',
  				],
  				borderWidth: 1
  			}]
  		}
  	});
  </script>
</body>
</html>