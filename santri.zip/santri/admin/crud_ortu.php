<?php 

include_once '../config/dao.php';
$dao = new Dao();

$aksi = $_POST['aksi'];

if ($aksi == "save") {
	// $idortu = $_POST['idortu']; 
	$nim = $_POST['nim'];
	$ayah = $_POST['ayah'];
	$ibu = $_POST['ibu'];
	$pekerjaan = $_POST['pekerjaan'];
	$alamat = $_POST['alamat'];
	$query = "INSERT INTO `orang_tua`(`nim`, `nama_ayah`, `nama_ibu`, `pekerjaan`, `alamat`) VALUES ('$nim','$ayah','$ibu','$pekerjaan','$alamat')";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Ditambah!.'); //ini
        document.location='orangtua.php';
      </script> 
    <?php
}
elseif ($aksi == "edit") {
	$idortu = $_POST['idortu']; 
	$nim = $_POST['nim'];
	$ayah = $_POST['ayah'];
	$ibu = $_POST['ibu'];
	$pekerjaan = $_POST['pekerjaan'];
	$alamat = $_POST['alamat'];
	$query = "UPDATE `orang_tua` SET `nim`='$nim',`nama_ayah`='$ayah',`nama_ibu`='$ibu',`pekerjaan`='$pekerjaan', `alamat`='$alamat' WHERE `id_orangtua`='$idortu'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Diubah!.');
        document.location='orangtua.php';
      </script> 
    <?php
}
else{
	$idortu = $_POST['idortu']; 
	$query = "DELETE FROM `orang_tua` WHERE id_orangtua = '$idortu'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Dihapus!.'); 
        document.location='orangtua.php';
      </script> 
    <?php
}
?>