<?php 
include_once '../config/dao.php';
$dao = new Dao();

$aksi = $_POST['aksi'];
if ($aksi == "save") {
	// $idortu = $_POST['idortu']; 
	$nim = $_POST['nim'];
	$id_target = $_POST['id_target'];
	$hasil = $_POST['hasil'];
	$ayat = $_POST['ayat'];
	$surah = "";
	$status = "";
	$id_surah2 = "";
	$ayat2 = "";
	$query = "select nama_surah from surah where id_surah = '$hasil'";
	$hsl = $dao->execute($query);
	foreach ($hsl as $value) {
		$surah = $value['nama_surah'];
	}

	$query = "select id_surah, ayat from target where id_target = '$id_target'";
	$hsl = $dao->execute($query);
	foreach ($hsl as $value) {
		$id_surah2 = $value['id_surah'];
		$ayat2 = $value['ayat'];
	}
	if ($dao->selisih($id_surah2,$hasil) < 0) {
		$status = "Tercapai";
	}
	elseif ($dao->selisih($id_surah2,$hasil) == 0) {
		if ($dao->selisih($ayat2,$ayat) <= 0) {
			$status = "Tercapai";
		}
		else{
			$status = "Belum Tercapai";
		}
	}
	else{
		$status = "Belum Tercapai";
	}
	// echo $status;
	$query = "INSERT INTO `hafalan`(`nim`, `id_target`, `id_surah`, `nama_surah`, `ayat`,`status`) VALUES ('$nim','$id_target','$hasil','$surah','$ayat','$status')";
	$hasil = $dao->execute($query);
	?>
	<script language="JavaScript">
        alert('Data Berhasil Ditambah!.'); //ini
        document.location='hafalan.php';
    </script> 
    <?php
}
else{
	$id = $_POST['idHafalan']; 
	$nim = $_POST['nim']; 
	// echo $nim;
	$query = "DELETE FROM `hafalan` WHERE id_hafalan = '$id'";
	$hasil = $dao->execute($query);
	?>
	<script language="JavaScript">
		<!-- alert('Data Berhasil Dihapus!.'); -->
		document.location='detail_hafalan.php?nim=<?php echo $nim ?>';
	</script> 
	<?php
}
?> 