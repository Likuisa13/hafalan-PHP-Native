<?php 

include_once '../config/dao.php';
$dao = new Dao();

$aksi = $_POST['aksi'];

if ($aksi == "save") {
	$id_surah = $_POST['surah'];
	$ayat = $_POST['ayat'];
	$query = "INSERT INTO `target`(`id_surah`, `ayat`) VALUES ('$id_surah','$ayat')";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Ditambah!.');
        document.location='target.php';
      </script> 
    <?php
}
elseif ($aksi == "edit") {
	$id_target = $_POST['id_target']; 
	$id_surah = $_POST['surah'];
	$ayat = $_POST['ayat'];
	$query = "UPDATE `target` SET `id_surah`='$id_surah',`ayat`='$ayat' WHERE `id_target`='$id_target'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Diubah!.');
        document.location='target.php';
      </script> 
    <?php
}
else{
	$id_target = $_POST['id_target']; 
	$query = "DELETE FROM `target` WHERE id_target = '$id_target'";
	$hasil = $dao->execute($query);
	?>
      <script language="JavaScript">
        alert('Data Berhasil Dihapus!.');
        document.location='target.php';
      </script> 
    <?php
}
?>