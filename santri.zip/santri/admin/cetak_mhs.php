<?php 
$html = '<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">';
$html .= '<center><h3>Data Mahasiswa</h3></center><hr/><br/>';
$html .= '<table class="table table-stripped" width="100%">
	<tr>
		<td>No</td>
		<td>NIM Mahasiswa</td>
		<td>Nama Mahasiswa</td>
		<td>Tempat Tanggal Lahir</td>
		<td>Jenis Kelamin</td>
		<td>Alamat</td>
		<td>Prodi</td>
		<td>Jurusan</td>
		<td>IPK</td>
		<td>Semester</td>
		<td>Jumlah Hafalan</td>
	</tr>';

include_once '../config/dao.php';
require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$no = 1;
$dao = new Dao();
$orang = $dao->tampilMahasiswa();
foreach ($orang as $value) {
	$html .= "<tr><td><center>".$no."</center></td>";
	$html .= "<td>".$value['nim']."</td>";
	$html .= "<td>".$value['nama_mahasiswa']."</td>";
	$html .= "<td>".$value['tempat_lahir'].", ".$value['tgl_lahir']."</td>";
	$html .= "<td>".$value['jenis_kelamin']."</td>";
	$html .= "<td>".$value['alamat']."</td>";
	$html .= "<td>".$value['prodi']."</td>";
	$html .= "<td>".$value['jurusan']."</td>";
	$html .= "<td>".$value['ipk']."</td>";
	$html .= "<td>".$value['semester']."</td>";
	$html .= "<td>".$value['jumlah_hafalan']."</td></tr>";
	$no++;
}
$html .= "</html>";
$dompdf->loadHtml($html);
	// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'landscape');
	// Rendering dari HTML Ke PDF
$dompdf->render();
	// Melakukan output file Pdf
$dompdf->stream('cetak_mhs.pdf');
?>