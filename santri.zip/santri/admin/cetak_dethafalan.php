<?php 
$nim = $_GET['nim'];
$nama = $_GET['nama'];

$html = '<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">';
$html .= '<center><h3>Data Ketercapaian Hafalan Mahasiswa</h3></center><hr/><br>';
$html .= '<table>';
$html .= "<tr><td>NIM</td><td> : ".$nim."</td></tr>";
$html .= "<tr><td>Nama</td><td> : ".$nama."</td></tr></table><br><br>";
$html .= '<table class="table table-stripped" width="100%">;
<tr>
	<td>No</td>
	<td>Waktu</td>
	<td>Target Hafalan</td>
	<td>Capaian Hafalan</td>
	<td>Status</td>
</tr>';

include_once '../config/dao.php';
require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$no = 1;
$dao = new Dao();
$orang = $dao->detailHafalan($nim);
foreach ($orang as $value) {
	$html .= "<tr><td><center>".$no."</center></td>";
	$html .="<td><center>".$value['waktu']."</center></td>";
	$html .="<td><center>".$value['nsurah']." Ayat ".$value['nayat']."</center></td>";
	$html .="<td>".$value['nama_surah']." Ayat ".$value['ayat']."</td>";
	$html .="<td>".$value['status']."</td>";
	$no++;
}
$html .= '<br><br><center><img width="140" height="200" src="../img/foto/'.$nim.'.jpg"></center>';
$html .= "</html>";
$dompdf->loadHtml($html);
	// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
	// Rendering dari HTML Ke PDF
$dompdf->render();
	// Melakukan output file Pdf
$dompdf->stream('cetak_detail_hafalan.pdf');


?>