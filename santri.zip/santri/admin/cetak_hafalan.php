<?php 
$html = '<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">';
$html .= '<center><h3>Data Ketercapaian Hafalan Mahasiswa</h3></center><hr/><br/>';
$html .= '<table class="table table-stripped" width="100%">
<tr>
	<td>No</td>
	<td>Waktu</td>
	<td>NIM Mahasiswa</td>
	<td>Nama Mahasiswa</td>
	<td>Status</td>
</tr>';

include_once '../config/dao.php';
require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$no = 1;
$dao = new Dao();
$orang = $dao->tampilHafalan();
foreach ($orang as $value) {
	$html .= "<tr><td><center>".$no."</center></td>";
	$html .="<td><center>".$value['waktu']."</center></td>";
	$html .="<td><center>".$value['nim']."</center></td>";
	$html .="<td>".$value['nama_mahasiswa']."</td>";
	$html .="<td>".$value['status']."</td>";
	$no++;
}
$html .= "</html>";
$dompdf->loadHtml($html);
	// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
	// Rendering dari HTML Ke PDF
$dompdf->render();
	// Melakukan output file Pdf
$dompdf->stream('cetak_hafalan.pdf');


?>