<?php 
include_once '../config/dao.php';
$dao = new Dao();
session_start();
$id = $_SESSION['id'];
$query ="UPDATE `user` SET status = 'offline' WHERE id_user='$id' ";
$dao->execute($query);
$_SESSION['username']=Null;
$_SESSION['level']=Null;
$_SESSION['id']=Null;
unset($_SESSION['username']);
unset($_SESSION['level']);
unset($_SESSION['id']);
session_unset();
session_destroy();
header("location:../");
?>