<?php 
error_reporting('off'); //untuk matiin pesan error
session_start();
if ($_SESSION['level'] != "Admin" || empty($_SESSION['level'])) {
  ?>
  <script language="JavaScript">
    alert('Silakan lakukan proses login terlebih dahulu !');
    document.location='../index.php';
  </script>
  <?php
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>STIMIK EL RAHMA | Monitoring dan Evaluasi</title>
  <link rel="icon" href="../img/logo.png">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="../bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
   folder instead of downloading all of them to reduce the load. -->
   <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
   <link rel="stylesheet" type="text/css" href="../datatable/dataTables.bootstrap.min.css">
   <!-- Google Font -->
   <link rel="stylesheet"
   href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
   <script type="text/javascript">
    function addTarget() {
      // alert('OK');
      $('#aksi').val('save');
      $('#id_target').val('');
      $('#surah').val('');
      $('#ayat').val('');
      $('#Target').modal('show');
    }

    function editTarget(id_target,id_surah,ayat) {
      $('#aksi').val('edit');
      $('#id_target').val(id_target);
      $('#surah').val(id_surah);
      $('#ayat').val(ayat);
      $('#Target').modal('show');
    }

    function delTarget(id, nama, ayat) {
      $('#idTarget').val(id);
      $('#namaSurah').text(nama);
      $('#ayatSurah').text(ayat);
      $('#aksi2').val('delete');
      $('#TargetDel').modal('show');
    }
  </script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">

    <header class="main-header">

      <!-- Logo -->
      <a href="index.php" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>S</b> E-R</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>STMIK</b> El-Rahma</span>
      </a>

      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->


      </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
          <div class="pull-left image">
            <img src="../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
          </div>
          <div class="pull-left info">
            <p>Rizqi Nurhidayah</p>
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
          </div>
        </div>

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
          <li class="header">MAIN NAVIGATION</li>
          <li>
            <a href="index.php">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
          </li>
          <li class="treeview">
            <a href="#">
              <i class="fa fa-file-code-o"></i>
              <span>Data Master</span>
              <span class="pull-right-container">
                <span class="label label-primary pull-right"></span>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="mahasiswa.php"><i class="fa fa-circle-o"></i> Data Mahasiswa</a></li>
              <li><a href="orangtua.php"><i class="fa fa-circle-o"></i> Data Orang Tua</a></li>
              <li><a href="target.php"><i class="fa fa-circle-o"></i> Data Target</a></li>
              <!-- <li><a href="target.php"><i class="fa fa-circle-o"></i> DATA HAFALAN</a></li> -->
            </ul>
          </li>
          <li>
            <a href="hafalan.php">
              <i class="fa fa-th"></i> <span>Data Hafalan</span>
              <span class="pull-right-container">
              </span>
            </a>
          </li>
          <li>
            <a href="logout.php">
              <i class="fa fa-sign-out"></i>
              <span>Log Out</span>
            </a>
          </li>
        </ul>
      </section>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Dashboard</li>
        </ol>
      </section>
      <!-- Main content -->
      <div class="container">
        <div class="col-md-12">
          <!-- menampilkan tabel yang tadi -->
          <h2><center>DATA TARGET</center></h2>
          <div class="container">
            <button type="button" class="btn btn-primary" onclick="addTarget();">
              <i class="fa fa-plus"> Tambah Data</i>
            </button>
            <a href="cetak_target.php" target="_blank"><button type="button" class="btn btn-warning">
              <i class="fa fa-print"> Cetak Data</i>
            </button></a><br><br>
            <table class="table table-striped table-responsive table-bordered" id="data">
              <!-- header table -->
              <thead class="btn-primary disabled"> 
                <tr>
                  <td>No</td>
                  <td>Surah</td>
                  <td>Ayat Ke</td>
                  <td>Aksi</td>
                </tr>
              </thead>
              <!-- body table -->
              <tbody>
                <?php 
        include_once '../config/dao.php'; //panggil file dao.php yang ada di dlm folder config

        $dao = new Dao();//membuat object dao
        $orang = $dao->tampilTarget();//memanggil function di dao untuk menampilkan data orang
        $no = 1;
        foreach ($orang as $value) {
          ?>
          <td><center><?php echo $no; ?></center></td>
          <td><center><?php echo $value['nama_surah']; ?></center></td>
          <td><center><?php echo $value['ayat']; ?></center></td>
          <td nowrap=""><center>
            <button class="btn btn-info" type="button" onclick="editTarget('<?php echo $value['id_target'] ?>','<?php echo $value['id_surah'] ?>','<?php echo $value['ayat'] ?>')">Edit</button>
            <button class="btn btn-danger" type="button" onclick="delTarget('<?php echo $value['id_target'] ?>', '<?php echo $value['nama_surah'] ?>', '<?php echo $value['ayat'] ?>')">Delete</button>
          </td>
        </tr>
        <?php
        $no++;
      }
      ?>
    </tbody>
  </table>
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.13
  </div>
  <strong>Copyright &copy; Rizqi Nurhidayah <a href="https://adminlte.io">STMIK EL-RAHMA</a>.</strong> Kerja Praktik UTY
</footer>


<!-- Modal Insert -->
<div class="modal" id="Target">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Data Target</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="crud_target.php" method="POST" role="form">
          <div class="row">
            <div class="col-md-6">
              <label>Surah</label>
              <input type="hidden" name="aksi" id="aksi">
              <input type="hidden" name="id_target" id="id_target">
              <select class="form-control" name="surah" id="surah">
                <option value="">Pilih Surah</option>
                <?php 
                $mhs = $dao->tampilSurah();
                foreach ($mhs as $value) {
                  ?>
                  <option value="<?php echo $value['id_surah']?>"><?php echo $value['nama_surah']?></option>
                  <?php
                }

                ?>
              </select>
            </div>
            <div class="col-md-6">
              <label>Ayat</label>
              <input type="text" name="ayat" id="ayat" class="form-control" placeholder="Ayat">
            </div>
          </div>

          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Delete -->
<div class="modal" id="TargetDel">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Data Target</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="crud_target.php" method="POST">

          <h3>Yakin akan menghapus data Target?</h3>
          <center><h2 id="namaSurah"></h2></center>
          <h3><center>Ayat : <span id="ayatSurah"></span></center></h3>
          <input type="hidden" name="id_target" id="idTarget">
          <input type="hidden" name="aksi" id="aksi2">
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Delete</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>


<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<!-- jQuery 3 -->
<script src="../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="../bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="../bower_components/chart.js/Chart.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script src="../datatable/dataTables.bootstrap.min.js"></script>
<script src="../datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#data').DataTable();
  } );
</script>
</body>
</html>
